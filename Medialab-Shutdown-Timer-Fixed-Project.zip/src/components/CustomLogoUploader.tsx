import React, { useState, useEffect, useRef } from 'react';
import { ImagePlus } from 'lucide-react';
import { sounds } from '../utils/audio';

interface CustomLogoUploaderProps {
  isArabic: boolean;
  className?: string;
}

const STORAGE_KEY = 'powertimer_custom_user_logo';

export const CustomLogoUploader: React.FC<CustomLogoUploaderProps> = ({ isArabic, className = '' }) => {
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Load saved logo from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved && saved.startsWith('data:image/')) {
        setLogoUrl(saved);
      }
    } catch {
      // LocalStorage might be disabled
    }
  }, []);

  const handleFileProcess = (file: File) => {
    if (!file || !file.type.startsWith('image/')) {
      alert(isArabic ? 'يرجى اختيار ملف صورة صالح (PNG, JPG, SVG, WebP)' : 'Please select a valid image file (PNG, JPG, SVG, WebP)');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert(isArabic ? 'حجم الصورة كبير جداً، يرجى اختيار صورة أقل من 5 ميجابايت' : 'Image is too large, please select an image under 5MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        setLogoUrl(result);
        sounds.playClick();
        try {
          localStorage.setItem(STORAGE_KEY, result);
        } catch {
          // Ignore quota errors
        }
      }
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileProcess(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileProcess(file);
    }
  };

  return (
    <div className={`relative select-none ${className}`}>
      {logoUrl ? (
        /* Permanent static custom logo display (NO change/remove hover overlay) */
        <div className="inline-flex items-center justify-center p-1 rounded-xl bg-white/50 border border-neutral-300/50 shadow-2xs">
          <img
            src={logoUrl}
            alt="Logo"
            className="max-h-11 sm:max-h-13 max-w-[170px] w-auto object-contain pointer-events-none rounded-lg"
          />
        </div>
      ) : (
        /* Hidden file input and initial upload trigger if no logo saved yet */
        <>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileChange}
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`h-11 sm:h-12 px-3.5 rounded-xl border border-dashed transition-all flex items-center gap-2 cursor-pointer shadow-2xs ${
              isDragging
                ? 'border-[#e85933] bg-orange-50/80 text-[#e85933] scale-[1.02]'
                : 'border-neutral-300 bg-white/80 hover:bg-white hover:border-[#e85933] text-neutral-600 hover:text-[#e85933]'
            }`}
            title={isArabic ? 'انقر لرفع شعار مخصص (PNG, JPG, SVG, WebP)' : 'Click to upload custom logo (PNG, JPG, SVG, WebP)'}
          >
            <div className="w-6 h-6 rounded-lg bg-[#ece9e2] text-neutral-500 flex items-center justify-center">
              <ImagePlus className="w-3.5 h-3.5" />
            </div>
            <span className="text-xs font-bold tracking-tight">
              {isArabic ? 'رفع شعار' : 'Upload Logo'}
            </span>
          </button>
        </>
      )}
    </div>
  );
};
