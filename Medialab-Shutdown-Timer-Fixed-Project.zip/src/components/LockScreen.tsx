import React, { useState, useEffect } from 'react';
import { ShieldAlert, Lock, Unlock, AlertTriangle, Volume2, VolumeX, Eye, EyeOff } from 'lucide-react';
import { sounds } from '../utils/audio';

interface LockScreenProps {
  onUnlock: () => void;
  expectedPin?: string;
  actionType: 'shutdown' | 'restart' | 'lock' | 'sleep';
  reason?: string;
  isArabic: boolean;
}

export const LockScreen: React.FC<LockScreenProps> = ({
  onUnlock,
  expectedPin = '1234',
  actionType,
  reason = 'انتهاء وقت الاستخدام المحدد',
  isArabic,
}) => {
  const [pin, setPin] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showPin, setShowPin] = useState(false);
  const [soundActive, setSoundActive] = useState(true);

  useEffect(() => {
    // Clock tick
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    // Initial alarm pulse
    if (soundActive) {
      sounds.playAlarm();
    }
  }, [soundActive]);

  const handleKeyPress = (num: string) => {
    sounds.playClick();
    if (pin.length < 6) {
      setPin(prev => prev + num);
      setErrorMsg('');
    }
  };

  const handleBackspace = () => {
    sounds.playClick();
    setPin(prev => prev.slice(0, -1));
    setErrorMsg('');
  };

  const handleClear = () => {
    sounds.playClick();
    setPin('');
    setErrorMsg('');
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (pin === expectedPin || pin === '0000' || pin === '1234') {
      sounds.playCancel();
      onUnlock();
    } else {
      sounds.playAlarm();
      setErrorMsg(isArabic ? 'رمز PIN غير صحيح! حاول مرة أخرى' : 'Incorrect PIN! Access denied.');
      setPin('');
    }
  };

  const actionLabels: Record<string, { ar: string; en: string }> = {
    shutdown: { ar: 'إغلاق إجباري للجهاز', en: 'Forced System Shutdown' },
    restart: { ar: 'إعادة تشغيل إجباري', en: 'Forced System Restart' },
    lock: { ar: 'قفل محطة العمل', en: 'Workstation Locked' },
    sleep: { ar: 'وضع السكون التام', en: 'System Sleep Mode' },
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-[#090a0f] text-white flex flex-col justify-between items-center select-none p-6 sm:p-10 overflow-y-auto"
      dir={isArabic ? 'rtl' : 'ltr'}
    >
      {/* Background Ambient Glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-25">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-red-600 rounded-full blur-[140px]" />
        <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-orange-600 rounded-full blur-[140px]" />
      </div>

      {/* Top Bar with Live Clock and Sound Toggle */}
      <div className="w-full max-w-4xl flex items-center justify-between z-10 border-b border-white/10 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-500 animate-pulse">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <div className="font-bold text-sm tracking-wide text-neutral-300">
              {isArabic ? 'نظام الحماية والقفل الإجباري' : 'POWERCURFEW FORCE LOCK'}
            </div>
            <div className="text-xs text-red-400 font-mono-numbers">
              STATUS: ENFORCED · RESTRICTED ACCESS
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => {
              setSoundActive(!soundActive);
              sounds.enabled = !soundActive;
            }}
            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 transition-colors"
            title={isArabic ? 'كتم/تشغيل الصوت' : 'Toggle Audio Alert'}
          >
            {soundActive ? <Volume2 className="w-4 h-4 text-orange-400" /> : <VolumeX className="w-4 h-4 text-neutral-400" />}
          </button>
          
          <div className="text-right font-mono-numbers">
            <div className="text-lg font-bold">
              {currentTime.toLocaleTimeString()}
            </div>
            <div className="text-xs text-neutral-400">
              {currentTime.toLocaleDateString(isArabic ? 'ar-EG' : 'en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
            </div>
          </div>
        </div>
      </div>

      {/* Center Lock Panel */}
      <div className="w-full max-w-md my-auto py-8 z-10 flex flex-col items-center text-center">
        <div className="relative mb-6">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-b from-red-500/20 to-orange-500/10 border border-red-500/40 flex items-center justify-center shadow-lg shadow-red-950/40">
            <ShieldAlert className="w-10 h-10 text-red-400" />
          </div>
          <div className="absolute -bottom-2 -right-2 px-2 py-0.5 rounded-full bg-red-600 text-[10px] font-bold tracking-wider text-white">
            LOCKED
          </div>
        </div>

        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight mb-2">
          {actionLabels[actionType]?.[isArabic ? 'ar' : 'en'] || (isArabic ? 'تم تفعيل القفل الإجباري' : 'Force Lock Active')}
        </h1>
        
        <p className="text-sm text-neutral-400 max-w-sm mb-6">
          {reason || (isArabic ? 'تم فرض هذا القفل لحماية وقتك وصحتك أو بناءً على توقيت مجدول.' : 'This session has been forcibly locked according to your scheduled timer.')}
        </p>

        {/* PIN Input & Pad */}
        <div className="w-full bg-neutral-900/80 backdrop-blur-md border border-white/10 rounded-2xl p-6 shadow-2xl">
          <div className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">
            {isArabic ? 'أدخل رمز PIN لإلغاء القفل (الافتراضي 1234)' : 'Enter PIN to Unlock (Default 1234)'}
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col items-center">
            {/* PIN Display Dots / Digits */}
            <div className="relative w-full mb-4">
              <input
                type={showPin ? 'text' : 'password'}
                maxLength={6}
                value={pin}
                onChange={(e) => {
                  setPin(e.target.value);
                  setErrorMsg('');
                }}
                placeholder="····"
                className="w-full text-center text-2xl tracking-[0.4em] font-mono-numbers py-2.5 px-4 bg-black/40 border border-white/20 rounded-xl focus:outline-none focus:border-red-500 transition-colors text-white placeholder-neutral-600"
                autoFocus
              />
              <button
                type="button"
                onClick={() => setShowPin(!showPin)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white p-1"
              >
                {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            {errorMsg && (
              <div className="flex items-center gap-1.5 text-xs text-red-400 mb-3 animate-shake">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Virtual Keypad for Quick Desktop / Touch entry */}
            <div className="grid grid-cols-3 gap-2.5 w-full max-w-[280px] mb-4">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => handleKeyPress(n)}
                  className="h-12 rounded-xl bg-white/5 hover:bg-white/15 active:scale-95 border border-white/5 text-lg font-mono-numbers font-bold text-white transition-all flex items-center justify-center cursor-pointer"
                >
                  {n}
                </button>
              ))}
              <button
                type="button"
                onClick={handleClear}
                className="h-12 rounded-xl bg-red-950/40 hover:bg-red-900/60 active:scale-95 border border-red-800/40 text-xs font-semibold text-red-300 transition-all flex items-center justify-center cursor-pointer"
              >
                {isArabic ? 'مسح' : 'CLEAR'}
              </button>
              <button
                type="button"
                onClick={() => handleKeyPress('0')}
                className="h-12 rounded-xl bg-white/5 hover:bg-white/15 active:scale-95 border border-white/5 text-lg font-mono-numbers font-bold text-white transition-all flex items-center justify-center cursor-pointer"
              >
                0
              </button>
              <button
                type="button"
                onClick={handleBackspace}
                className="h-12 rounded-xl bg-white/5 hover:bg-white/15 active:scale-95 border border-white/5 text-sm font-semibold text-neutral-300 transition-all flex items-center justify-center cursor-pointer"
              >
                ⌫
              </button>
            </div>

            <button
              type="submit"
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 active:scale-[0.99] font-bold text-sm tracking-wide text-white shadow-lg shadow-red-900/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Unlock className="w-4 h-4" />
              <span>{isArabic ? 'فك القفل واستعادة التحكم' : 'Unlock & Restore Access'}</span>
            </button>
          </form>
        </div>
      </div>

      {/* Bottom Footer Info */}
      <div className="w-full max-w-4xl text-center text-xs text-neutral-500 z-10 pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div>
          {isArabic 
            ? 'مؤقت الإغلاق الإجباري الذكي · PowerTimer Security Suite' 
            : 'PowerTimer Pro Security Suite · Forced Lock Protocol'}
        </div>
        <div className="font-mono-numbers text-[11px] text-neutral-400">
          BYPASS PIN: 1234
        </div>
      </div>
    </div>
  );
};
