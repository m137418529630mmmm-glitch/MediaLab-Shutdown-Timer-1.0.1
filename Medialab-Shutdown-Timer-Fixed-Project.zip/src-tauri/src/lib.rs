#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::process::Command;

#[tauri::command]
fn execute_action(action: String, force: bool) -> Result<(), String> {
    match action.as_str() {
        "shutdown" => {
            let mut command = Command::new("shutdown.exe");
            command.args(["/s", "/t", "0"]);
            if force { command.arg("/f"); }
            command.spawn().map_err(|e| format!("Shutdown failed: {}", e))?;
        }
        "restart" => {
            let mut command = Command::new("shutdown.exe");
            command.args(["/r", "/t", "0"]);
            if force { command.arg("/f"); }
            command.spawn().map_err(|e| format!("Restart failed: {}", e))?;
        }
        "lock" => {
            Command::new("rundll32.exe")
                .args(["user32.dll,LockWorkStation"])
                .spawn().map_err(|e| format!("Lock failed: {}", e))?;
        }
        "sleep" => {
            Command::new("rundll32.exe")
                .args(["powrprof.dll,SetSuspendState", "0,1,0"])
                .spawn().map_err(|e| format!("Sleep failed: {}", e))?;
        }
        _ => return Err(format!("Unknown action: {}", action)),
    }
    Ok(())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![execute_action])
        .run(tauri::generate_context!())
        .expect("error while running Medialab Shutdown Timer");
}
