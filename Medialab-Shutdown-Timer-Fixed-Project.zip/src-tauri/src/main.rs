#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    medialab_shutdown_timer_lib::run();
}
